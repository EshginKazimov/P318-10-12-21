﻿using FrontToBack.Areas.AdminPanel.Data;
using FrontToBack.DataAccessLayer;
using FrontToBack.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBack.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class SliderImageController : Controller
    {
        private readonly AppDbContext _dbContext;

        public SliderImageController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> Index()
        {
            var sliderImages = await _dbContext.SliderImages.ToListAsync();

            return View(sliderImages);
        }

        public IActionResult Create()
        {
            var sliderImagesCount = _dbContext.SliderImages.Count();
            if (sliderImagesCount >= 5)
                return BadRequest();

            return View();
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Create(SliderImage sliderImage)
        //{
        //    var sliderImagesCount = _dbContext.SliderImages.Count();
        //    if (sliderImagesCount >= 5)
        //        return BadRequest();

        //    if (!ModelState.IsValid)
        //        return View();

        //    if (!sliderImage.Photo.IsImage())
        //    {
        //        ModelState.AddModelError("Photo", "Yalniz shekil upload ede bilersiz");
        //        return View();
        //    }

        //    if (!sliderImage.Photo.IsSizeAllowed(1))
        //    {
        //        ModelState.AddModelError("Photo", "Maximum 1 MB");
        //        return View();
        //    }

        //    var fileName = await FileUtil.GenerateFile(Constants.ImageFolderPath, sliderImage.Photo);

        //    sliderImage.Name = fileName;
        //    await _dbContext.SliderImages.AddAsync(sliderImage);
        //    await _dbContext.SaveChangesAsync();

        //    return RedirectToAction(nameof(Index));
        //}

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SliderImage sliderImage)
        {
            if (!ModelState.IsValid)
                return View();

            var sliderImagesCount = await _dbContext.SliderImages.CountAsync();
            if (sliderImage.Photos.Length > 5 - sliderImagesCount)
            {
                ModelState.AddModelError("Photos", $"Max {5 - sliderImagesCount} eded shekil ola biler.");
                return View();
            }

            foreach (var photo in sliderImage.Photos)
            {
                if (!photo.IsImage())
                {
                    ModelState.AddModelError("Photos", $"{photo.FileName} shekil deyil.");
                    return View();
                }

                if (!photo.IsSizeAllowed(1))
                {
                    ModelState.AddModelError("Photos", $"{photo.FileName} 1 MB-dan boyukdur.");
                    return View();
                }

                var fileName = await FileUtil.GenerateFile(Constants.ImageFolderPath, photo);

                var newSliderImage = new SliderImage { Name = fileName };

                await _dbContext.SliderImages.AddAsync(newSliderImage);
                await _dbContext.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var sliderImage = await _dbContext.SliderImages.FindAsync(id);
            if (sliderImage == null)
                return NotFound();

            return View(sliderImage);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeleteSliderImage(int? id)
        {
            if (id == null)
                return NotFound();

            var sliderImage = await _dbContext.SliderImages.FindAsync(id);
            if (sliderImage == null)
                return NotFound();

            var path = Path.Combine(Constants.ImageFolderPath, sliderImage.Name);

            if (System.IO.File.Exists(path))
            {
                System.IO.File.Delete(path);
            }

            _dbContext.SliderImages.Remove(sliderImage);
            await _dbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Update(int? id)
        {
            if (id == null)
                return NotFound();

            var sliderImage = await _dbContext.SliderImages.FindAsync(id);
            if (sliderImage == null)
                return NotFound();

            return View(sliderImage);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int? id, SliderImage sliderImage)
        {
            if (id == null)
                return NotFound();

            if (id != sliderImage.Id)
                return BadRequest();

            var dbSliderImage = await _dbContext.SliderImages.FindAsync(id);
            if (dbSliderImage == null)
                return NotFound();

            if (!ModelState.IsValid)
                return View(dbSliderImage);

            if (!sliderImage.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Yalniz shekil upload ede bilersiz");
                return View(dbSliderImage);
            }

            if (!sliderImage.Photo.IsSizeAllowed(1))
            {
                ModelState.AddModelError("Photo", "Maximum 1 MB");
                return View(dbSliderImage);
            }            

            var path = Path.Combine(Constants.ImageFolderPath, dbSliderImage.Name);
            if (System.IO.File.Exists(path))
                System.IO.File.Delete(path);

            var fileName = await FileUtil.GenerateFile(Constants.ImageFolderPath, sliderImage.Photo);

            dbSliderImage.Name = fileName;
            await _dbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
